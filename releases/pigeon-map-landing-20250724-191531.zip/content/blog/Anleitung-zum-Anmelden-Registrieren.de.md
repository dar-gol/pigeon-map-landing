---
title: "Anmelde-/Registrierungsanleitung"
date: "2025-07-16"
description: "Wie melde ich mich an/registriere mich im Pigeon Map System?"
---

## Video-Anleitung

Auf unserem YouTube-Kanal gibt es ein Video, das Schritt für Schritt zeigt, wie man sich bei Pigeon Map anmeldet und registriert

<div align="center">
  <iframe
        width="560" height="315"
        src="https://www.youtube.com/embed/HEJqSvcv0fU?si=jG75KXH8J0EsA_9x"
        title="Tutorial Pigeon Map"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
      ></iframe>
</div>