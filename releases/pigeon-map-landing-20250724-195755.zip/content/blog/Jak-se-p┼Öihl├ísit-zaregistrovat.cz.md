---
title: "Instrukce pro přihlášení/registraci"
date: "2025-07-16"
description: "Jak se přihlásit/zaregistrovat do systému Pigeon Map?"
---

## Video návod

Na našem YouTube kanálu existuje video, které krok za krokem prezentuje, jak se přihlásit a zaregistrovat do Pigeon Map

<div align="center">
  <iframe
        width="560" height="315"
        src="https://www.youtube.com/embed/HEJqSvcv0fU?si=jG75KXH8J0EsA_9x"
        title="Tutorial Pigeon Map"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
      ></iframe>
</div>