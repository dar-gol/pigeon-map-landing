---
title: "Instrukcja logowania/rejestracji"
date: "2025-07-16"
description: "W jaki sposób zalogować/zarejestrować się do systemu Pigeon Map?"
---

## Wideo instrukcja

Na naszym kanale YouTube istnieje film który prezentuje krok po kroku w jaki sposób zalogować się oraz zarejestrować do Pigeon Map

<div align="center">
  <iframe
        width="560" height="315"
        src="https://www.youtube.com/embed/HEJqSvcv0fU?si=jG75KXH8J0EsA_9x"
        title="Tutorial Pigeon Map"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
      ></iframe>
</div>
