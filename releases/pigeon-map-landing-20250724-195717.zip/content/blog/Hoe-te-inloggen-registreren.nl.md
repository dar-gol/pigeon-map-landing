---
title: "Inlog/Registratie Instructies"
date: "2025-07-16"
description: "Hoe in te loggen/registreren in het Pigeon Map systeem?"
---

## Video Tutorial

Op ons YouTube kanaal staat een video die stap voor stap laat zien hoe je inlogt en registreert bij Pigeon Map

<div align="center">
  <iframe
        width="560" height="315"
        src="https://www.youtube.com/embed/HEJqSvcv0fU?si=jG75KXH8J0EsA_9x"
        title="Tutorial Pigeon Map"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
      ></iframe>
</div>