---
title: "Login/Registration Instructions"
date: "2025-07-16"
description: "How to login/register to the Pigeon Map system?"
---

## Video Tutorial

On our YouTube channel there is a video that presents step by step how to login and register to Pigeon Map

<div align="center">
  <iframe
        width="560" height="315"
        src="https://www.youtube.com/embed/HEJqSvcv0fU?si=jG75KXH8J0EsA_9x"
        title="Tutorial Pigeon Map"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
      ></iframe>
</div>